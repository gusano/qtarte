"""arte7recorder-qt"""
